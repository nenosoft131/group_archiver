import fcntl
from typing import Optional, TextIO


class FileLock:
    def __init__(self, path: str) -> None:
        self.path: str = path
        self.fd: Optional[TextIO] = None

    def acquire(self) -> None:
        self.fd = open(self.path, "w")
        try:
            fcntl.flock(self.fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError("Another instance is already running")

    def release(self) -> None:
        if self.fd:
            fcntl.flock(self.fd, fcntl.LOCK_UN)
            self.fd.close()